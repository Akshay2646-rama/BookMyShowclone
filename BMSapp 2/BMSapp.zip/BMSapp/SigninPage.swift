//
//  SigninPage.swift
//  BMSapp
//
//  Created by Nxtwave on 13/09/25.
//

import SwiftUI
import GoogleSignIn
import GoogleSignInSwift


struct SigninPage: View {
    @State private var phoneNumber: String = ""
    @State private var isSignedIn: Bool = false
    @StateObject var viewModel = SignIntegerViewModel()
    
    var body: some View {
        NavigationStack{
            VStack{
                GoogleSignInButton {
                    Task {
                        await viewModel.Signin()
                        isSignedIn = true
                    }
                }
                .padding()
                Text("Or")
                HStack {
                    
                    Text("🇮🇳  +91")
                        .fontWeight(.medium)
                    
                    TextField("Continue with mobile number", text: $phoneNumber)
                        .keyboardType(.numberPad)
                        .foregroundColor(.black)
                }
                .padding(.vertical, 10)
                .padding(.horizontal)
            }
            .navigationDestination(isPresented: $isSignedIn) {
                Tabview()
                    .navigationBarBackButtonHidden()
            }
        }
    }
}

#Preview {
    SigninPage()
}
