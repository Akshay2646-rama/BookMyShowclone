//
//  Tabview.swift
//  BMSapp
//
//  Created by Nxtwave on 15/09/25.
//

import SwiftUI

struct Tabview: View {
    var body: some View {
        TabView {
            ContentView()
                .tabItem{
                    Image(systemName: "house")
                    Text("Home")
                }
            
            Accout()
                .tabItem {
                    Image(systemName: "person.circle")
                    Text("Account")
                }
            
        }
    }
}

#Preview {
    Tabview()
}
