//
//  Accout.swift
//  BMSapp
//
//  Created by Nxtwave on 15/09/25.
//

import SwiftUI
import GoogleSignIn
import GoogleSignInSwift


struct Accout: View {
    @StateObject private var Modal = SignIntegerViewModel()
    @State private var issignout: Bool = false
    var body: some View {
        NavigationStack{
            VStack{
                    VStack{
                        if let url = Modal.profile?.imageURL {
                            AsyncImage(url: url) { image in
                                image.resizable()
                                    .scaledToFill()
                                    .frame(width: 100, height: 100)
                                    .clipShape(Circle())
                            } placeholder: {
                                ProgressView()
                            }
                        }
                        Text("\(Modal.profile?.name)")
                            .font(.headline)
                            .padding()
                        Text("\(Modal.profile?.email)")
                            .font(.subheadline)
                            .padding()
                        Button{
                            issignout = true
                        }label: {
                            Text("Sign Out")
                        }
                        
                    }
                
            }
            .navigationDestination(isPresented: $issignout) {
                SigninPage()
            }
        }
    }
}

#Preview {
    Accout()
}
