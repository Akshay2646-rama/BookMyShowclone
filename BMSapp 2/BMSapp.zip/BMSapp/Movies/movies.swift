//
//  movies.swift
//  BMSapp
//
//  Created by Nxtwave on 05/09/25.
//

import SwiftUI

struct movies: View {
    let movie: Movie
    let colums:[GridItem]=[GridItem(.flexible()),GridItem(.flexible())]
    var body: some View {
        NavigationStack{
            ZStack{
                VStack{
                    HStack{
                        Text("Now showing")
                        Spacer()
                        Image(systemName: "magnifyingglass")
                    }
                    .padding()
                    HStack{
                        Text("Hyderbad | 22 Movies")
                            .foregroundStyle(.gray)
                        Spacer()
                    }
                    .padding(.horizontal)
                    Carusoles()
                    Filter()
                }
            }
        }
    }
}

#Preview {
    movies(movie: mockMovies[0])
}
