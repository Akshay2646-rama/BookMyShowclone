//
//  ConfimationScreen.swift
//  BMSapp
//
//  Created by Nxtwave on 05/09/25.
//

import SwiftUI

struct ConfimationScreen: View {
    let movie: Movie
    let date: String
    let time: String
    let seats: [String]
    var body: some View {
        NavigationStack{
            VStack(spacing: 20) {
                Text("Booking Confirmed 🎉")
                    .font(.largeTitle)
                    .bold()
                
                Text("Movie: \(movie.title)")
                Text("Date: \(date)")
                Text("Time: \(time)")
                Text("Seats: \(seats.joined(separator: ", "))")
                    .bold()
                
                Spacer()
            }
        }
    }
}

#Preview {
    ConfimationScreen(
        movie: mockMovies[0],
        date: "22-9-2025",
        time: "9:30 AM",
        seats: ["A1", "A2", "A3"]
    )
}
