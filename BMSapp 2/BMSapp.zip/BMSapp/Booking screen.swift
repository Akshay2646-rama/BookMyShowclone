//
//  Booking screen.swift
//  BMSapp
//
//  Created by Nxtwave on 04/09/25.
//

import SwiftUI

struct Booking_screen: View {
    var movie: Movie
    @State private var selectedSeats: [String] = []
    let column : [GridItem] = [GridItem(.flexible()),
                               GridItem(.flexible()),
                               GridItem(.flexible()),
                               GridItem(.flexible())]
    @State var isbook: Bool = false
                              
    var body: some View {
        NavigationStack{
            VStack {
                Text("Select Seats for \(movie.title)")
                    .font(.headline)
                    .padding()
                LazyVGrid(columns: column) {
                    ForEach(movie.seats, id: \.self) { seat in
                        Button{
                            if selectedSeats.contains(seat) {
                                selectedSeats.removeAll { $0 == seat }
                            } else {
                                selectedSeats.append(seat)
                            }
                        }label: {
                            Text(seat)
                                .frame(width: 60, height: 40)
                                .background(selectedSeats.contains(seat) ? Color.green : Color.gray)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                        }
                        
                    }
                }
                Button{
                    isbook = true
                }label: {
                    Text("Confirm Booking")
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.red)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                        .padding()
                }
            }
            .navigationDestination(isPresented: $isbook) {
                ConfimationScreen(
                    movie: movie,
                    date: "22-9-2025",
                    time: movie.showTimes.first ?? "",
                    seats: selectedSeats
                )
            }
        }
    }
}

#Preview {
    Booking_screen(movie: mockMovies[0])
}
