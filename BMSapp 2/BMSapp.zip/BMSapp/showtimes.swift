//
//  showtimes.swift
//  BMSapp
//
//  Created by Nxtwave on 03/09/25.
//

import SwiftUI

struct showtimes: View {
    let movie:Movie
    @State var isclicked:Bool = false
    var body: some View {
        NavigationStack{
            VStack{
                Text("Showtimes")
                    VStack(alignment: .leading) {
                        Text(movie.title)
                            .font(.headline)
                        Text("22-9-2025")
                        HStack{
                        ForEach(movie.showTimes, id: \.self) { showtime in
                                Button{
                                    isclicked = true 
                                }label: {
                                    Text(showtime)
                                        .padding()
                                        .background(Color.red.opacity(0.8))
                                        .foregroundColor(.white)
                                        .cornerRadius(10)
                                        
                                }
                            }
                        }
                        Text("29-9-2025")
                        HStack{
                        ForEach(movie.showTimes, id: \.self) { showtime in
                                Button{
                                    isclicked = true
                                }label: {
                                    Text(showtime)
                                        .padding()
                                        .background(Color.red.opacity(0.8))
                                        .foregroundColor(.white)
                                        .cornerRadius(10)
                                        
                                }
                            }
                        }
                    }
                    .padding(.vertical, 4)
                
            }
            .sheet(isPresented: $isclicked){
                Booking_screen(movie: movie)
            }
        }
    }
}

#Preview {
    showtimes(movie: mockMovies[0])
}
